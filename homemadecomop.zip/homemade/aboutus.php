<html>
<body>
  <p>we at troubleclear (maids) providing you a platform where you can find your desired and suitable maids/cooks according to your need and convenience.</p>
<p>We understand the problem of finding a maid these days and the problem every housewife facing while dealing with them. We have designed the whole process according to customer needs and convenience.</p>
<p>No more compromise with your maids due to lack of options.</p>
<p>Troubleclear (maids) gives you number of experienced and verified maids data for free. Choose them, contact them and hire them at your terms and conditions.</p>
<br><br>
<center><img src="http:\\homemade.hostzi.com\homemade\home_made_icon.png" style="width: 120px; height: 100px;" /></center>
</body>
</html>