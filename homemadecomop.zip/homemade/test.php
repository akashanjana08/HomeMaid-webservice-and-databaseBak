<?php
   
    $intval = 12;
    echo (float) ($intval*1.0);
                
exit(0);

?>